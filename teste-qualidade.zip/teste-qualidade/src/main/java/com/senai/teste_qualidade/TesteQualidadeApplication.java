package com.senai.teste_qualidade;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TesteQualidadeApplication {

	public static void main(String[] args) {
		SpringApplication.run(TesteQualidadeApplication.class, args);
	}

}
